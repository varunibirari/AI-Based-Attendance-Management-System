# TODO: Fix JPA Lecture-Student Mapping Error

**✅ Step 1: Create TODO.md** - Track progress

**✅ Step 2: Edit Student.java** - Add @ManyToOne Lecture lecture field

**✅ Step 3: Verify application starts** - Run Spring Boot app

Run: `mvn spring-boot:run` or use IDE run button to test startup.

**⏳ Step 4: Test relationships** - Check database/attendance functionality

**⏳ Step 5: Complete task**

