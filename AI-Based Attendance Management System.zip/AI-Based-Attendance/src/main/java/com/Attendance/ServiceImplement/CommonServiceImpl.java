package com.Attendance.ServiceImplement;

public interface CommonServiceImpl {

    public void removeMessage();
}
